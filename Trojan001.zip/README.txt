Malware name: Trojan001.exe
Compiled in win32
Destruction Level: low
potential data loss: Yes
corrupts MBR: No
Disables Task Manager: Yes
Easy to remove: Yes

more information down here

Data loss can happen from the BSOD at the end of it if no files have been saved.
I've decided to put a .reg file on my GitHub page it's called Enable.reg to just reenable
the Task Manager and there the malware has been removed.